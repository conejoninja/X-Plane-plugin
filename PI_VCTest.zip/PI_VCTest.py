from SandyBarbourVCUtilities import *
from XPLMMenus import *
from XPWidgetDefs import *
from XPWidgets import *
from XPStandardWidgets import *

class PythonInterface:
	def XPluginStart(self):
		self.Name = "VCTest"
		self.Sig =  "SandyBarbour.Python.VCTest"
		self.Desc = "A plugin to test the VC bridge."

		self.MAX_INTEGER_ITEMS = 3
		self.MAX_FLOAT_ITEMS = 7

		self.IntegerDataRefDesc = ["VC Index", "VCT Index", "Look At"]
		self.FloatDataRefDesc = ["x Offset", "y Offset", "z Offset", "H Offset", "P Offset", "R Offset", "Zoom"]

		# Create our menu
		Item = XPLMAppendMenuItem(XPLMFindPluginsMenu(), "Python - VCTest", 0, 1)
		self.VCTestMenuHandlerCB = self.VCTestMenuHandler
		self.Id = XPLMCreateMenu(self, "VCTest", XPLMFindPluginsMenu(), Item, self.VCTestMenuHandlerCB, 0)
		XPLMAppendMenuItem(self.Id, "VCTest", 1, 1)

		self.MenuItem1 = 0
		self.IntValue = [0, 0, 0]
		self.FloatValue = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
		self.LowerLimits = [1, 0, 0]
		self.UpperLimits = [20, 18, 10]

		return self.Name, self.Sig, self.Desc

	def XPluginStop(self):
		if (self.MenuItem1 == 1):
			XPDestroyWidget(self, self.VCTestWidget, 1)
			self.MenuItem1 = 0

		XPLMDestroyMenu(self, self.Id)
		pass

	def XPluginEnable(self):
		return 1

	def XPluginDisable(self):
		pass

	def XPluginReceiveMessage(self, inFromWho, inMessage, inParam):
		pass

	def VCTestMenuHandler(self, inMenuRef, inItemRef):
		if (inItemRef == 1):
			if (self.MenuItem1 == 0):
				self.CreateVCTest(300, 600, 300, 550)
				self.MenuItem1 = 1
			else:
				if(not XPIsWidgetVisible(self.VCTestWidget)):
					XPShowWidget(self.VCTestWidget)
		pass

	def CreateVCTest(self, x, y, w, h):
		x2 = x + w
		y2 = y - h
		VCTestIntegerText = []
		VCTestFloatText = []

		self.VCTestWidget = XPCreateWidget(x, y, x2, y2, 1, "Python - VCTest by Sandy Barbour", 1,	0, xpWidgetClass_MainWindow)
		XPSetWidgetProperty(self.VCTestWidget, xpProperty_MainWindowHasCloseBoxes, 1)
		VCTestWindow = XPCreateWidget(x+50, y-50, x2-50, y2+50, 1,	"",	0, self.VCTestWidget, xpWidgetClass_SubWindow)
		XPSetWidgetProperty(VCTestWindow, xpProperty_SubWindowType, xpSubWindowStyle_SubWindow)

		self.VCTestIntegerEdit = []
		self.VCTestIntegerUpArrow = []
		self.VCTestIntegerDownArrow = []

		for Item in range(self.MAX_INTEGER_ITEMS):

			VCTestIntegerText.append(XPCreateWidget(x+60, y-(70 + (Item*30)), x+115, y-(92 + (Item*30)),
								1,				 		# Visible
								self.IntegerDataRefDesc[Item],	# desc
								0,				 		# root
								self.VCTestWidget,
								xpWidgetClass_Caption))

			self.VCTestIntegerEdit.append(XPCreateWidget(x+120, y-(70 + (Item*30)), x+210, y-(92 + (Item*30)),
								1, "0", 0, self.VCTestWidget,
								xpWidgetClass_TextField))

			XPSetWidgetProperty(self.VCTestIntegerEdit[Item], xpProperty_TextFieldType, xpTextEntryField)

			self.VCTestIntegerUpArrow.append(XPCreateWidget(x+212, y-(66 + (Item*30)), x+224, y-(81 + (Item*30)),
								1, "", 0, self.VCTestWidget,
								xpWidgetClass_Button))

			XPSetWidgetProperty(self.VCTestIntegerUpArrow[Item], xpProperty_ButtonType, xpLittleUpArrow)

			self.VCTestIntegerDownArrow.append(XPCreateWidget(x+212, y-(81 + (Item*30)), x+224, y-(96 + (Item*30)),
								1, "", 0, self.VCTestWidget,
								xpWidgetClass_Button))

			XPSetWidgetProperty(self.VCTestIntegerDownArrow[Item], xpProperty_ButtonType, xpLittleDownArrow)

		self.VCTestFloatEdit = []
		self.VCTestFloatUpArrow = []
		self.VCTestFloatDownArrow = []

		for Item in range(self.MAX_FLOAT_ITEMS):

			VCTestFloatText.append(XPCreateWidget(x+60, y-(160 + (Item*30)), x+115, y-(182 + (Item*30)),
								1,				 		# Visible
								self.FloatDataRefDesc[Item],	# desc
								0,				 		# root
								self.VCTestWidget,
								xpWidgetClass_Caption))

			self.VCTestFloatEdit.append(XPCreateWidget(x+120, y-(160 + (Item*30)), x+210, y-(182 + (Item*30)),
								1, "0", 0, self.VCTestWidget,
								xpWidgetClass_TextField))

			XPSetWidgetProperty(self.VCTestFloatEdit[Item], xpProperty_TextFieldType, xpTextEntryField)

			self.VCTestFloatUpArrow.append(XPCreateWidget(x+212, y-(156 + (Item*30)), x+224, y-(171 + (Item*30)),
								1, "", 0, self.VCTestWidget,
								xpWidgetClass_Button))

			XPSetWidgetProperty(self.VCTestFloatUpArrow[Item], xpProperty_ButtonType, xpLittleUpArrow)

			self.VCTestFloatDownArrow.append(XPCreateWidget(x+212, y-(171 + (Item*30)), x+224, y-(186 + (Item*30)),
								1, "", 0, self.VCTestWidget,
								xpWidgetClass_Button))

			XPSetWidgetProperty(self.VCTestFloatDownArrow[Item], xpProperty_ButtonType, xpLittleDownArrow)

		self.VCTestAcquireButton = XPCreateWidget(x+50, y-380, x+140, y-402,
						1, "Acquire", 0, self.VCTestWidget,
						xpWidgetClass_Button)

		XPSetWidgetProperty(self.VCTestAcquireButton, xpProperty_ButtonType, xpPushButton)

		self.VCTestReleaseButton = XPCreateWidget(x+50, y-410, x+140, y-432,
						1, "Release", 0, self.VCTestWidget,
						xpWidgetClass_Button)

		XPSetWidgetProperty(self.VCTestReleaseButton, xpProperty_ButtonType, xpPushButton)

		self.VCTestSetButton = XPCreateWidget(x+50, y-440, x+140, y-462,
						1, "Set Camera", 0, self.VCTestWidget,
						xpWidgetClass_Button)

		XPSetWidgetProperty(self.VCTestSetButton, xpProperty_ButtonType, xpPushButton)

		self.VCTestRefreshButton = XPCreateWidget(x+50, y-470, x+140, y-492,
						1, "Refresh", 0, self.VCTestWidget,
						xpWidgetClass_Button)

		XPSetWidgetProperty(self.VCTestRefreshButton, xpProperty_ButtonType, xpPushButton)

		# Register our widget handler
		self.VCTestHandlerCB = self.VCTestHandler
		XPAddWidgetCallback(self, self.VCTestWidget, self.VCTestHandlerCB)
		pass

	def VCTestHandler(self, inMessage, inWidget,	inParam1, inParam2):
		if (inMessage == xpMessage_CloseButtonPushed):
			if (self.MenuItem1 == 1):
				XPHideWidget(self.VCTestWidget)
			return 1

		if (inMessage == xpMsg_PushButtonPressed):

			if (inParam1 == self.VCTestAcquireButton):
				if (VC_CameraPluginReady()):
					VC_AcquireCamera()
				return 1

			if (inParam1 == self.VCTestReleaseButton):
	 			VC_ReleaseCamera()
				return 1

			if (inParam1 == self.VCTestSetButton):
	 			VC_SetCamera()
				return 1

			if (inParam1 == self.VCTestRefreshButton):
				self.IntValue[0] = VC_GetCameraIndex()
				self.IntValue[1] = VC_GetCameraTypeIndex()
				self.IntValue[2] = VC_GetLookAtAircraft()
				self.FloatValue[0] = VC_GetXOffset()
				self.FloatValue[1] = VC_GetYOffset()
				self.FloatValue[2] = VC_GetZOffset()
				self.FloatValue[3] = VC_GetHeadingOffset()
				self.FloatValue[4] = VC_GetPitchOffset()
				self.FloatValue[5] = VC_GetRollOffset()
				self.FloatValue[6] = VC_GetZoomRatio()
				for Item in range(self.MAX_INTEGER_ITEMS):
					buffer = "%d" % (self.IntValue[Item])
					XPSetWidgetDescriptor(self.VCTestIntegerEdit[Item], buffer)
				for Item in range(self.MAX_FLOAT_ITEMS):
					buffer = "%f" % (self.FloatValue[Item])
					XPSetWidgetDescriptor(self.VCTestFloatEdit[Item], buffer)
				return 1

			for Item in range(self.MAX_INTEGER_ITEMS):
				if (inParam1 == self.VCTestIntegerUpArrow[Item]):
					self.IntValue[Item] += 1;
					if (self.IntValue[Item] > self.UpperLimits[Item]):
						self.IntValue[Item] = self.LowerLimits[Item]
					buffer = "%d" % (self.IntValue[Item])
					XPSetWidgetDescriptor(self.VCTestIntegerEdit[Item], buffer)
					if (Item == 0):
						VC_SetCameraIndex(self.IntValue[0])
					if (Item == 1):
						VC_SetCameraTypeIndex(self.IntValue[1])
					if (Item == 2):
						VC_SetLookAtAircraft(self.IntValue[2])
					return 1

			for Item in range(self.MAX_INTEGER_ITEMS):
				if (inParam1 == self.VCTestIntegerDownArrow[Item]):
					self.IntValue[Item] -= 1
					if (self.IntValue[Item] < self.LowerLimits[Item]):
						self.IntValue[Item] = self.UpperLimits[Item]
					buffer = "%d" % (self.IntValue[Item])
					XPSetWidgetDescriptor(self.VCTestIntegerEdit[Item], buffer)
					if (Item == 0):
						VC_SetCameraIndex(self.IntValue[0])
					if (Item == 1):
						VC_SetCameraTypeIndex(self.IntValue[1])
					if (Item == 2):
						VC_SetLookAtAircraft(self.IntValue[2])
					return 1
			for Item in range(self.MAX_FLOAT_ITEMS):
				if (inParam1 == self.VCTestFloatUpArrow[Item]):
					self.FloatValue[Item] += 1.0
					buffer = "%d" % (self.FloatValue[Item])
					XPSetWidgetDescriptor(self.VCTestFloatEdit[Item], buffer)
					if (Item == 0):
						VC_SetXOffset(self.FloatValue[0])
					if (Item == 1):
						VC_SetYOffset(self.FloatValue[1])
					if (Item == 2):
						VC_SetZOffset(self.FloatValue[2])
					if (Item == 3):
						VC_SetHeadingOffset(self.FloatValue[3])
					if (Item == 4):
						VC_SetPitchOffset(self.FloatValue[4])
					if (Item == 5):
						VC_SetRollOffset(self.FloatValue[5])
					if (Item == 6):
						VC_SetZoomRatio(self.FloatValue[6])
					return 1

			for Item in range(self.MAX_FLOAT_ITEMS):
				if (inParam1 == self.VCTestFloatDownArrow[Item]):
					self.FloatValue[Item] -= 1.0
					buffer = "%d" % (self.FloatValue[Item])
					XPSetWidgetDescriptor(self.VCTestFloatEdit[Item], buffer)
					if (Item == 0):
						VC_SetXOffset(self.FloatValue[0])
					if (Item == 1):
						VC_SetYOffset(self.FloatValue[1])
					if (Item == 2):
						VC_SetZOffset(self.FloatValue[2])
					if (Item == 3):
						VC_SetHeadingOffset(self.FloatValue[3])
					if (Item == 4):
						VC_SetPitchOffset(self.FloatValue[4])
					if (Item == 5):
						VC_SetRollOffset(self.FloatValue[5])
					if (Item == 6):
						VC_SetZoomRatio(self.FloatValue[6])
					return 1

		return 0
